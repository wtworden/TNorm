

#QUIET = None


##### for sympy implementation
#ABS_SIGN_MATRIX = abs(sign_matrix())

#IN_SAGE = False

#try:
#    from sage.all import RR
#    IN_SAGE = True
#except:
#    IN_SAGE = False
