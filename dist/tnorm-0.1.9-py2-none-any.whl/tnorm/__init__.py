
from tnorm.version import version, __version__


#import tnorm.kernel
#import tnorm.GUI

from tnorm.TN_wrapper import TN_wrapper as load

#IN_SAGE=False