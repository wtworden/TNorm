name = "tnorm"

from tnorm.version import __version__

from tnorm.TN_wrapper import TN_wrapper as load

