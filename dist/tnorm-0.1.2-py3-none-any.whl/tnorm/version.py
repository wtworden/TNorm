


''' Provides one variable __version__.

Caution: All code in here will be executed by setup.py. '''

__version__ = '0.1.2'
